import os 
import shutil


count=-1
num=0
num1=1
temp='C:\\Users\\pf4\\Documents\\Casual Conversations face list\\'
newfold='face smooshed'
dst=temp+newfold

#os.mkdir(newfold)#make a new folder
        
    
for dirpath, dirnames, files in os.walk('C:\\Users\\pf4\\Documents\\Casual Conversations face list\\List of faces\\SubjectFolders'):
            print("test")

            if count==10:
                count=0
            
            for name in files:#copy the first face for ever participant896and give them each a uniqe name with a counter
                if num==1:

                    print(str(name)[0:4])
                    os.rename(os.path.join(dirpath, name),os.path.join(dirpath,(name[:22]+"{}.jpg").format(num1)))
                    src= os.path.join(dirpath, (name[:22]+"{}.jpg").format(num1))
                    shutil.copy(src,dst)
                    num1=num1+1
                    num=0
                    count=10
                    break
                else:
                    num=num+1
                    
                    