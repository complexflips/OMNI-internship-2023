import os 

logfile="test for skin type 1copy.txt"
logfile1="test for skin type 2copy.txt"
logfile2="test for skin type 3copy.txt"
logfile3="test for skin type 4copy.txt"
logfile4="test for skin type 5copy.txt"
logfile5="test for skin type 6copy.txt"
listfile='superlist1.txt'
listfile1='superlist2.txt'
listfile2='superlist3.txt'
listfile3='superlist4.txt'
listfile4='superlist5.txt'
listfile5='superlist6.txt'



walkfolder='E:\\SubjectFolders'
#os.mkdir(newfold)#make a new folder
        
def makelist(folder):#make a list to store the uniqe names of each copied file
                     #this code should have been done with set up face but i didn't have the forsight to do that
    thelist=[]
    count=-1
    num=0
    num1=1
    for dirpath, dirnames, files in os.walk(folder):
                if count==10:
                    count=0
                    
                for name in files:
                    if num==2:
                        thelist.append({#copy the second name in a list overv with its uniqe counter
                             'from folder':os.path.basename(os.path.normpath(dirpath)),
                             'file name':(name[:22]+"{}.jpg").format(num1)
                             })
                        num1=num1+1
                        num=0
                        count=10
                        break
                    else:
                        num=num+1
    return thelist

def textsave(thelist,logfile,superlist):#save to a text file
    with open(logfile, 'r') as txt:
         with open(superlist, 'w') as txt1:
            for line in txt:    
                for info in thelist:
                    if line.startswith('A'or'H'or'N'or'R'or'M'):#skip the lines with the folder names
                        break
                    if str(info['from folder'])==str(line[:line.find('\n')]):
                        txt1.write(info['file name']+'\n')
                        break
                    
thelist=makelist(walkfolder)

textsave(thelist,logfile,listfile)

thelist=makelist(walkfolder)

textsave(thelist,logfile1,listfile1)

thelist=makelist(walkfolder)

textsave(thelist,logfile2,listfile2)

thelist=makelist(walkfolder)

textsave(thelist,logfile3,listfile3)

thelist=makelist(walkfolder)

textsave(thelist,logfile4,listfile4)

thelist=makelist(walkfolder)

textsave(thelist,logfile5,listfile5)
