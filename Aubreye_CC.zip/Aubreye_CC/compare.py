def count_lines(superlist_file, failure_file):
    superlist_lines = set()
    line_count = 0

    # Read the lines from superlist1.txt and store the first four characters in a set
    with open(superlist_file, 'r') as superlist:
        superlist_lines = set(line[0:4]+line[22:line.find('.')-1] for line in superlist.read().splitlines())

    

    # Read the lines from failure.txt and count the occurrences
    with open ('fail6.txt','w') as txt:
        with open(failure_file, 'r') as failure:
            for line in failure:
                # Extract the first four characters from the line and check if they exist in the superlist_lines set
                if (line.strip()[0:4]+(line.strip()[22:line.find('\n')])) in superlist_lines:
                    
                    txt.write(line[0:4]+'\n')
                    print('test')
                    
                    line_count += 1

    return line_count

if __name__ == '__main__':
    superlist_file = 'superlist6.txt'
    failure_file = 'failure.txt'

    count = count_lines(superlist_file, failure_file)
    print(f"The number of occurrences: {count}")
