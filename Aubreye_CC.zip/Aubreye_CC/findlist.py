import csv

fields =["what folder to take from"]#initialize tile columns for CSV
row =''#initalize array for CSV
name=0
ffile=""
gen=""
age=""
skin=""
num=0
num1=0

logfile="CasualConversations"


with open("test for skin type 6.txt", 'w') as txt1:#create a new text file 
        with open (logfile+'.txt') as txt:#open casual conversations txt folder
                
                for line in txt:#iterate the lines in the log
                    
                    if (line.find("\": {")!=-1 & line.find("label")==-1):#set up to find the letter directory each participant is in
                         dire=line[5:line.find(':')-1]

                         
                    if ((line.find("CasualConversations") != -1 ) & (num1==0)):#get the 4 character ID of each participant
                         ffile=(''.join([chr for chr in line[31:39] if (((chr >='0' and chr <='9')) or (chr >= 'A' and chr<='Z'))]))
                         num1=1

                    if(line.find("skin-type")!=-1):#check if the skin type is the same as the testing sample needed
                                                   #if it is save the letter and 4 character ID to the text file
                        skin=line[26]
                        if (skin=='6'):
                             row=(dire+'\n')
                             txt1.write(row)


                             row=(ffile+'\n')
                             txt1.write(row)
                        
                        num=num+1
                        

                    if(num==3):
                        num=0                        
                        num1=0