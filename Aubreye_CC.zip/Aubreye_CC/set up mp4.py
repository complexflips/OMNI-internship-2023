import os 
import shutil


def setup(dst5,logfile5):
    count=-1
    for dirpath, dirnames, files in os.walk('E:\\Videos'):
        print("test")
        print(dirpath)
        with open (logfile5+'.txt') as txt:#open test txt folder   
            for line in txt:
                if count==10:#alternate to the second video in each participants folder
                    count=0  #i don't entirely remember why this is here but i remember it does something important 
                    break
                for name in files: #check the names in the text document
                    if (line[0]!='N'):    #if the participant is not in the NO folder
                        if ((str(name)[0:4]==str(line[1:5])) and (dirpath.find(line[0])!=-1)):
                            src= os.path.join(dirpath, name)
                            try:
                                shutil.copy(src,dst5)
                            except:
                                print('boo2')
                            count=10
                            break
                        else:
                            count=0
                            break
                    else:#if they are offset every value by one to account
                        if ((str(name)[0:4]==str(line[2:6])) and (dirpath.find(line[0:1])!=-1)):
                            src= os.path.join(dirpath, name)
                            try:
                                shutil.copy(src,dst5)
                            except:
                                print('boo2')
                            count=10
                            break
                        else:
                            count=0
                            break
                    

temp='C:\\Users\\pf4\\Documents\\Casual Conversations face list\\'
logfile="test for skin type 1"
newfold='video recodings skin type 1'
logfile1="test for skin type 2"
newfold1='video recodings skin type 2'
logfile2="test for skin type 3"
newfold2='video recodings skin type 3'
logfile3="test for skin type 4"
newfold3='video recodings skin type 4'
logfile4="test for skin type 5"
newfold4='video recodings skin type 5'
logfile5="test for skin type 6"
newfold5='video recodings skin type 6'

dst=temp+newfold
dst1=temp+newfold1
dst2=temp+newfold2
dst3=temp+newfold3
dst4=temp+newfold4
dst5=temp+newfold5

setup(dst,logfile)
setup(dst1,logfile1)
setup(dst2,logfile2)
setup(dst3,logfile3)
setup(dst4,logfile4)
setup(dst5,logfile5)