import csv


fields =["Name", "From File", "Age", "Gender", "Skin Type"]#initialize tile columns for CSV
row =["","","","",""]#initalize array for CSV
name=0
ffile=""
gen=""
age=""
skin=""
num=0
num1=0

logfile="CasualConversations"


with open("information.csv", 'w') as csvfile:#create a new CSV file and writer
        
        writes = csv.writer(csvfile)
        writes.writerow(fields)#write the title comlums in the CSV
    
    
        with open (logfile+'.txt') as txt:#open log txt folder
                
                for line in txt:#iterate the lines in the log
                    
                    
                    if ((line.find("CasualConversations") != -1 ) & (num1==0)):#find the first part of an entry

                         ffile=(''.join([chr for chr in line[32:39] if (((chr >='0' and chr <='9') or (chr>='A' and chr <='Z')))]))
                         num1=1


                    if (line.find("age") != -1):# check if the line is a face match alarm
                        
                        if (line.find("N/A")==-1):#if age is given get the age
                            age=line[20:22]
                        else:
                             age="N/A" 
                        num=num+1   
                        
                    if(line.find("gender")!=-1):#if gender is given get the gender
                        
                        print(line.strip())
                        if(line.find("Female")!=-1):
                             gen="Female"
                        elif(line.find("Male")!=-1):
                             gen="Male"
                        elif(line.find("N/A")!=-1):
                             gen="N/A"
                        else:
                             gen="other"
                        num=num+1

                    if(line.find("skin-type")!=-1):#get the skin type
                        
                        skin=line[26]
                        num=num+1
                        

                    if(num==3):#write to the CSV File
                        
                        num=0
                        name=name+1

                        row=[name,ffile,age,gen,skin]
                        writes.writerow(row)
                        num1=0