from PIL import Image
import os

#crop the images to make them smaller for entry into the NVR

left = 180
top = 0
right = 980
bottom = 800
dst='C:\\Users\\pf4\\Documents\\Casual Conversations face list\\face smooshed'

for dirpath, dirnames, files in os.walk('C:\\Users\\pf4\\Documents\\Casual Conversations face list\\2023_07_12_102420_template(Block List)\\image'):
    for name in files:    
        img=Image.open(os.path.join(dirpath,name))
        
        img_res = img.crop((left, top, right, bottom)) 
        img_res.save(os.path.join(dst,name))
        print ('test')
        
 
 
