import pandas as pd
import csv
from glob import glob
from datetime import timedelta
import os
import re



offset=pd.to_timedelta('6:2:46')
# read all log files
log_files = glob('./log_folder/*.txt')
logs = pd.concat((pd.read_csv(file, delimiter='\t', 
                              names=['counting number', 'alarm', 'date',  
                                     'alarm type', 'camera_info', 'why is this needed']) 
                  for file in log_files))
# Filter out irrelevant alarm types
logs = logs[~logs['alarm type'].isin(['Alarm-out', 'Intelligent Alarm'])]

# Define a function to extract the name
def extract_name(row):
    if 'Block List---Name:' in row:
        return (str(row).split('Block List---Name:')[1].strip())[0:4]
    elif 'IP Camera---' in row:
        return (str(row).split('IP Camera---')[1].strip())
    else:
        return None  # or some default value

logs['person'] = logs['camera_info'].apply(extract_name)
logs['datetime'] = pd.to_datetime(logs['date'])

# read all video list files
video_list_files = glob('./video_list_folder/fail6.txt')
video_list = pd.concat((pd.read_csv(file, names=['personfail']) for file in video_list_files))

# placeholder for output data
output = []
correct=0
incorrect=0
didgood='NA'
everbad='NA'
falsepos='NA'

# read and process each segment file
segment_files = glob('./segment_folder/length skin type 6.txt')
for file in segment_files:
    with open(file, 'r') as f:
        lines = f.read().splitlines()
        for i in range(0, len(lines)):
            
            if lines[i].find('Filename:')!=-1:#find the first line that matters in the text folder
                                              #and get name start time and duration
                segment_name = lines[i].split('Filename: ')[1]

                end_time = (pd.to_datetime(lines[i+1].split('Start Time: ')[1]))+offset-timedelta(days=1) # the file formatting was off and caused start time to be end time

                duration = pd.to_timedelta(lines[i+2].split('Duration: ')[1])
                start_time = end_time - duration


                if end_time < start_time:#account for a day rollover
                    end_time += timedelta(days=1)

                segment_logs = logs[(logs['datetime'] >= start_time) & #get only the part of the logs within the timespan of the videos
                                    (logs['datetime'] <= end_time)]

                if ((video_list['personfail']).isin([int(segment_name)]).any() and (segment_logs['person'].str.count(segment_name).sum()==0)):
                    #if someone is not in the NVR database, check for false positives
                    falsepos=0
                    correct=-999
                    incorrect=-999
                    didgood='NA'
                    everbad='NA'
                    falsepos=((segment_logs['person']).size)-(segment_logs['person'].str.count('Stranger').sum())

                else:# if someon is in the NVR database count how many times they appeared and if/how many times they were misidentified 
                    falsepos=0
                    correct=segment_logs['person'].str.count(segment_name).sum()
                    incorrect=(segment_logs['person']).size-correct
                    if correct==0:
                        didgood='False'
                    else:
                        didgood='True'
                    if incorrect>0:
                        everbad='True'
                    else:
                        everbad="False"
                    
                
            
                output.append([segment_name, correct, incorrect, 
                            didgood, everbad, falsepos, start_time, end_time])


# write to csv file
with open('output6.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Name", "Count of Correct Identifications", 
                     "Count of Incorrect Identifications", "Correct at Least Once", 
                     "Incorrect at Least Once", "False Positive"])
    writer.writerows(output)
