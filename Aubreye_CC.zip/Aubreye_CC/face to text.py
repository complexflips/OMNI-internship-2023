import os 


count=-1
temp='C:\\Users\\pf4\\Documents\\Casual Conversations face list\\'
newfold='face smooshed'
dst=temp+newfold

#os.mkdir(newfold)#make a new folder
        
# make a list of all the file names
# because I am stupid and renamed everything
for dirpath, dirnames, files in os.walk('C:\\Users\\pf4\\Documents\\Casual Conversations face list\\face smooshed'):
    with open("list.txt", 'w') as txt:
        for name in files:
            txt.write(name+'\n')