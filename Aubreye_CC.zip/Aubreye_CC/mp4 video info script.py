import os
from moviepy.editor import VideoFileClip
import datetime


def get_video_info(folder_path):
    # Get a list of all MP4 files in the folder
    video_files = [file for file in os.listdir(folder_path) if file.endswith('.MP4')]
    total_length = (0) 
    video_start_time= (0)
    video_info = []

    for file in video_files:
        file_path = os.path.join(folder_path, file)

        # Open the video file and extract information
        clip = VideoFileClip(file_path)
        video_duration = round(clip.duration)*1.001883 
        total_length += video_duration  # Accumulate video duration in the total length
        video_start_time = (video_start_time+video_duration)
        clip.close()
        # Store the video information in a dictionary and add it to the list
        video_info.append({
            'filename': file[:4],
            'start_time': video_start_time,
            'duration': video_duration
        })

    return total_length, video_info

def save_info_to_file(total_length, video_info, output_file):
    with open(output_file, 'w') as file:
        # Calculate the total length of all videos
        file.write(f'Total length: {format_time(total_length)} seconds\n\n')
        file.write('Video Info:\n')
        for info in video_info:
            #convert the start time and duration to the desired format
            start_time_str=format_time(info['start_time'])
            duration_str=format_time(info['duration'])

            # Write the video information to the file
            file.write(f"Filename: {info['filename']}\n")
            file.write(f"Start Time: {start_time_str}\n")
            file.write(f"Duration: {duration_str}\n\n")

def format_time(seconds):
    time_str=datetime.timedelta(seconds=seconds)
    return time_str


if __name__ == '__main__':
    # Prompt the user to enter the folder path and output file name
    folder_path0 = 'C:\\Users\\pf4\\Documents\\Casual Conversations face list\\video recodings skin type 1'#input("Enter the folder path containing MP4 files: ")
    output_file0 = 'segment_folder\\length skin type 1.txt'#input("Enter the output file name: ")
    folder_path = 'C:\\Users\\pf4\\Documents\\Casual Conversations face list\\video recodings skin type 2'#input("Enter the folder path containing MP4 files: ")
    output_file = 'segment_folder\\length skin type 2.txt'#input("Enter the output file name: ")
    folder_path1 = 'C:\\Users\\pf4\\Documents\\Casual Conversations face list\\video recodings skin type 3'#input("Enter the folder path containing MP4 files: ")
    output_file1 = 'segment_folder\\length skin type 3.txt'#input("Enter the output file name: ")
    folder_path2 = 'C:\\Users\\pf4\\Documents\\Casual Conversations face list\\video recodings skin type 4'#input("Enter the folder path containing MP4 files: ")
    output_file2 = 'segment_folder\\length skin type 4.txt'#input("Enter the output file name: ")
    folder_path3 = 'C:\\Users\\pf4\\Documents\\Casual Conversations face list\\video recodings skin type 5'#input("Enter the folder path containing MP4 files: ")
    output_file3 = 'segment_folder\\length skin type 5.txt'#input("Enter the output file name: ")
    folder_path4 = 'C:\\Users\\pf4\\Documents\\Casual Conversations face list\\video recodings skin type 6'#input("Enter the folder path containing MP4 files: ")
    output_file4 = 'segment_folder\\length skin type 6.txt'#input("Enter the output file name: ")

    
    # Retrieve video information from the folder
    total_length0, video_info0 = get_video_info(folder_path0)
    total_length, video_info = get_video_info(folder_path)
    total_length1, video_info1 = get_video_info(folder_path1)
    total_length2, video_info2 = get_video_info(folder_path2)
    total_length3, video_info3 = get_video_info(folder_path3)
    #total_length4, video_info4 = get_video_info(folder_path4)

    
    # Save the video information to the output file
    save_info_to_file(total_length0, video_info0, output_file0)
    save_info_to_file(total_length, video_info, output_file)
    save_info_to_file(total_length1, video_info1, output_file1)
    save_info_to_file(total_length2, video_info2, output_file2)
    save_info_to_file(total_length3, video_info3, output_file3)
    #save_info_to_file(total_length4, video_info4, output_file4)
